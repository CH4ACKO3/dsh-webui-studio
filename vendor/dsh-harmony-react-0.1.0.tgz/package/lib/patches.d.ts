import type { HarmonySourcePatch } from 'dsh-harmony';
import type { InsertElementOptions, RemoveElementOptions, ReplaceElementOptions, ReplaceStringLiteralOptions, TransformPropsOptions, WrapElementOptions } from './types.js';
export declare function replaceElement(options: ReplaceElementOptions): HarmonySourcePatch;
export declare function wrapElement(options: WrapElementOptions): HarmonySourcePatch;
export declare function insertBefore(options: InsertElementOptions): HarmonySourcePatch;
export declare function insertAfter(options: InsertElementOptions): HarmonySourcePatch;
export declare function transformProps(options: TransformPropsOptions): HarmonySourcePatch;
export declare function removeElement(options: RemoveElementOptions): HarmonySourcePatch;
export declare function replaceStringLiteral(options: ReplaceStringLiteralOptions): HarmonySourcePatch;
