export declare const STUDIO_RUNTIME_KEY = "__DSH_HARMONY_STUDIO_RUNTIME__";
export type StudioVariableValue = string | number | boolean;
export interface StudioVariableDefinition {
    id: string;
    label: string;
    control: 'color' | 'length' | 'number' | 'boolean' | 'enum' | 'string';
    options?: readonly string[];
    constraints?: {
        min?: number;
        max?: number;
        step?: number;
    };
}
export interface StudioElementDefinition {
    id: string;
    label: string;
    boundary: {
        surfaceId: string;
        path: readonly string[];
    };
    source: {
        file: string;
        line?: number;
        column?: number;
    };
    variables?: readonly StudioVariableDefinition[];
}
export interface StudioVariableBinding {
    get(): StudioVariableValue;
    set(value: StudioVariableValue): void | Promise<void>;
    subscribe?(listener: () => void): () => void;
}
export interface StudioElementRegistration {
    owner: string;
    element: StudioElementDefinition;
    bindings: Readonly<Record<string, StudioVariableBinding>>;
}
export interface StudioVariablesRegistration {
    owner: string;
    variables: readonly StudioVariableDefinition[];
    bindings: Readonly<Record<string, StudioVariableBinding>>;
}
export interface StudioElementSnapshot {
    owner: string;
    element: StudioElementDefinition;
    values: Readonly<Record<string, StudioVariableValue>>;
}
export interface StudioVariablesSnapshot {
    owner: string;
    variables: readonly StudioVariableDefinition[];
    values: Readonly<Record<string, StudioVariableValue>>;
}
export interface StudioRegistrySnapshot {
    elements: readonly StudioElementSnapshot[];
    variables: readonly StudioVariablesSnapshot[];
}
export interface StudioBrowserRuntime {
    registerElement(registration: StudioElementRegistration): () => void;
    registerVariables(registration: StudioVariablesRegistration): () => void;
}
export declare function registerStudioElement(registration: StudioElementRegistration): () => void;
export declare function registerStudioVariables(registration: StudioVariablesRegistration): () => void;
